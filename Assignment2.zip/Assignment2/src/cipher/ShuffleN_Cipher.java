package cipher;

import java.util.Random;

/**
 * @author Youmeng Hin
 * @version 02/27/2020 This class is responsible for shuffling letters the
 * message
 */
public class ShuffleN_Cipher implements Cipher {

    private int shuffles;

    /**
     * Initializes the instance variable shuffles to the value in the parameter
     *
     * @param s The number of shuffles
     */
    public ShuffleN_Cipher(int s) {
        shuffles = Math.abs(s);
    }

    /**
     * Initializes the instance variable shuffles to a random between 1 and 10
     */
    public ShuffleN_Cipher() {
        Random rand = new Random();
        shuffles = 1 + rand.nextInt(10);
    }

    /**
     * Takes in the message and shuffle it once
     *
     * @param str message to be encoded
     * @return encoded version of message
     */
    private String shuffle(String str) {
        String shuffled = "";
        String firstHalf = str.substring(0, (str.length() + 1) / 2);
        String secondHalf = str.substring((str.length() + 1) / 2, str.length());
        for (int i = 0; i < str.length() / 2; i++) {
            shuffled += firstHalf.charAt(i);
            shuffled += secondHalf.charAt(i);
        }
        if (str.length() % 2 != 0) {
            shuffled += firstHalf.charAt(firstHalf.length() - 1);
        }
        return shuffled;
    }

    /**
     * Encodes the message shuffles amount of time using the private method
     * shuffle
     *
     * @param plainText message to be encoded
     * @return encoded message
     */
    @Override
    public String encode(String plainText) {
        if(shuffles > 0){
            for (int i = 0; i < shuffles; i++)
                plainText = shuffle(plainText);
        }
        return plainText;
    }
}
