package cipher;

/**
 * @author Youmeng Hin
 * @version 02/27/2020
 * Interface that contains the abstract method encode
 */
public interface Cipher {

    /**
     * Abstract method to be defined in class ShiftN_Cipher and class ShuffleN_Cipher
     * @param plainText Message to be encoded in class ShiftN_Cipher and class ShuffleN_Cipher 
     * @return The encoded message
     */
    String encode(String plainText);
}
