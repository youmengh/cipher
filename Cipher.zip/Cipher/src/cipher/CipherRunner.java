package cipher;

import java.util.Scanner;

/**
 * @author Youmeng Hin
 * @version 02/27/2020 Main class for Cipher program
 */
public class CipherRunner {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String user = "";
        String msg = "";
        int num = 0;
        ShiftN_Cipher s;
        ShuffleN_Cipher sh;
        while(!user.equalsIgnoreCase("q")){
            System.out.println("What would you like to do? (E)Encode message (Q)Quit");
            user = input.nextLine();
            if(user.equalsIgnoreCase("e")){
                System.out.println("Enter the message you would like to encode: ");
                msg = input.nextLine();
                System.out.println("Enter the desired number of shifts: ");
                num = input.nextInt();
                s = new ShiftN_Cipher(num);
                msg = s.encode(msg);
                System.out.println("Enter the desired number of shuffles: ");
                num = input.nextInt();
                sh = new ShuffleN_Cipher(num);
                msg = sh.encode(msg);
                System.out.println("Encoded message: " + msg);
            }
        }
        System.out.println("Program endded.");
    }
}

