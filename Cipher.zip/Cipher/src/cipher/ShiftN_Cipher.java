package cipher;

import java.util.Random;

/**
 * @author Youmeng Hin
 * @version 02/27/2020 This class is responsible for shifting letters in the
 * message
 */
public class ShiftN_Cipher implements Cipher {

    private int shifts;

    /**
     * Initializes the instance variable shifts to the value in the parameter
     *
     * @param s The number of shifts
     */
    public ShiftN_Cipher(int s) {
        shifts = s;
    }

    /**
     * Initializes the instance variable shifts to a random value between 1 and
     * 26
     */
    public ShiftN_Cipher() {
        Random rand = new Random();
        shifts = 1 + rand.nextInt(26);
    }

    /**
     * Takes in a single character and encode the character according to the
     * shift value
     *
     * @param c character to be encoded
     * @return encoded version of character
     */
    private char shiftSingle(char c) {
        int temp = shifts;
        char max = 0;
        char min1 = 0;
        char min2 = 0;
        int range = 0;
        if (Character.isDigit(c)) {
            range = 10;
            max = '9';
            min1 = '0';
            min2 = '/';
        } else if (Character.isAlphabetic(c)) {
            range = 26;
            if (Character.isUpperCase(c)) {
                max = 'Z';
                min1 = 'A';
                min2 = '@';
            } else if (Character.isLowerCase(c)) {
                max = 'z';
                min1 = 'a';
                min2 = '`';
            }
        } else {
            return c;
        }
        if (shifts > range || shifts < -range) {
            shifts = shifts % range;
        }
        if ((c + shifts) > max) {
            shifts = c + shifts - max;
            c = (char) min2;
        } else if ((c + shifts) < min1) {
            shifts = shifts + c - min2;
            c = (char) max;
        }
        c = (char) (c + shifts);
        shifts = temp;
        return c;
    }

    /**
     * Encodes every letter using the private method shiftSingle
     *
     * @param plainText message to be encoded
     * @return encoded message
     */
    @Override
    public String encode(String plainText) {
        String encoded = "";
        for (int i = 0; i < plainText.length(); i++) {
            encoded += shiftSingle(plainText.charAt(i));
        }
        return encoded;
    }

}
